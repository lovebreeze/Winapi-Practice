#include "Bitmap.h"
#include "SceneManager.h"
namespace ENGINE
{
	Bitmap::~Bitmap()
	{
		DeleteDC(memDC);
		DeleteObject(hBitmap);
	}
	VOID Bitmap::Load(std::string name)
	{
		memDC = CreateCompatibleDC(SceneMgr->GetBackDC());
		hBitmap = (HBITMAP)LoadImageA(NULL, name.c_str(), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		SelectObject(memDC, hBitmap); //�޸� DC�� ��Ʈ�� �̹�������

		BITMAP BitMap;

		return VOID();
	}
	VOID Bitmap::SetDrawSize(UINT width, UINT height)
	{
		dest = { (LONG)width,(LONG)height };
		SetPivot(pivotType);
	}
	VOID Bitmap::SetPivot(INT pivot)
	{
		pivotType = pivot;

		int halfWidth = dest.cx * 0.5f;
		int halfHeight = dest.cy * 0.5f;
		this->pivot = { -halfWidth, -halfHeight };

		if (pivot & Pivot::Left) this->pivot.x += halfWidth;
		if (pivot & Pivot::Right) this->pivot.x -= halfWidth;
		if (pivot & Pivot::Top) this->pivot.y += halfHeight;
		if (pivot & Pivot::Bottom) this->pivot.y -= halfHeight;
	}
	BOOL Bitmap::BitBlt(INT32 x, INT32 y)
	{
		return ::BitBlt(SceneMgr->GetBackDC(), pivot.x + x, pivot.y + y, src.right, src.bottom, memDC, src.left, src.top, SRCCOPY);
	}

	BOOL Bitmap::StretchBlt(INT32 x, INT32 y)
	{
		return ::StretchBlt(SceneMgr->GetBackDC(), pivot.x + x, pivot.y + y, dest.cx, dest.cy, memDC, src.left, src.top, src.right, src.bottom, SRCCOPY);
	}

	BOOL Bitmap::TransparentBlt(INT32 x, INT32 y, UINT transparent)
	{
		return ::TransparentBlt(SceneMgr->GetBackDC(), pivot.x + x , pivot.y + y , dest.cx, dest.cy , memDC, src.left , src.top ,src.right,src.bottom, transparent);
	}
}