#include "Bitmap.h"
#include "SceneManager.h"
namespace ENGINE
{
	Bitmap::~Bitmap()
	{
		DeleteDC(memDC);
		DeleteObject(hBitmap);
	}
	VOID Bitmap::Load(std::string name)
	{
		memDC = CreateCompatibleDC(SceneMgr->GetBackDC());
		hBitmap = (HBITMAP)LoadImageA(NULL, name.c_str(), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		SelectObject(memDC, hBitmap); //�޸� DC�� ��Ʈ�� �̹�������

		BITMAP BitMap;

		return VOID();
	}
}