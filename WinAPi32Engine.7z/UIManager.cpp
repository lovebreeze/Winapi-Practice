#include "UIManager.h"

namespace ENGINE
{

	UIManager::~UIManager()
	{
		Clear();
	}

	VOID UIManager::Initialize()
	{
		Clear();
	}

	VOID UIManager::Clear()
	{
		for (std::pair<std::string, UIPanel*>pair : map_UI) DEL(pair.second);
		map_UI.clear();
	}

	VOID UIManager::Update()
	{
		//�θ� ������� �θ��ʿ��� update ȣ�� �ϰ� ����.
		for (std::pair<std::string, UIPanel*>pair : map_UI)
			if (!pair.second->GetParent())
				pair.second->Update();
	}

	VOID UIManager::Draw()
	{
		for (std::pair<std::string, UIPanel*> pair : map_UI)
			if (!pair.second->GetParent()) pair.second->Draw();
	}

	UIPanel* UIManager::GetUI(std::string name)
	{
		return nullptr;
	}

	BOOL UIManager::Remove(std::string name)
	{
		auto ui = GetUI(name);
		if (nullptr != ui)
		{
			map_UI.erase(name);
			DEL(ui);

			return TRUE;
		}
		return FALSE;
	}

}