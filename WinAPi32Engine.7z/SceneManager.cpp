#include "SceneManager.h"
#include"TimeManager.h"
#include "InputManager.h"
#include "ResourceManager.h"

namespace ENGINE
{
	SceneManager::~SceneManager() { Release(); }

	VOID SceneManager::Initialize(HWND hWnd, UINT32 width, UINT32 height)
	{
		if (!hWnd) return;

		this->hWnd = hWnd;
		this->width = width;
		this->height = height;

		hDC = GetDC(hWnd);
		hBackDC = CreateCompatibleDC(hDC);
		TimeMgr->Initialize(FPS); // FPS: EngineMecro::ENGINE::enum::FPS
		ResourceMgr->Initialize();
		InputMgr->Initialize();
	}

	VOID SceneManager::Release()
	{
		currScene = NULL;
		ResourceMgr->Destroy();
		InputMgr->Destroy();
		TimeMgr->Destroy();


		for (std::pair<std::string, Scene*> scene : scenes) REL_DEL(scene.second)
		scenes.clear();
		DeleteObject(hBackDC);
		ReleaseDC(hWnd, hDC);
	}

	VOID SceneManager::Render()
	{
		if (!TimeMgr->Update()) return;

		if (currScene)
		{
			Update();
			InputMgr->Update();
			Draw();
		}
		SetScene();
	}
	VOID SceneManager::SetScene()
	{
		if (nextScene.empty()) return;
		if (currScene) 
		{ 
			currScene->Release(); 
			ResourceMgr->Clear();
		}

		currScene = scenes[nextScene];
		currScene->Initialize();
		nextScene = "";
	}
	VOID SceneManager::Update()
	{
		currScene->Update(TimeMgr->DeltaTime());
	}
	VOID SceneManager::Draw()
	{
		HBITMAP backBitmap = CreateDIBSectionRe();
		SelectObject(hBackDC, backBitmap);

		currScene->Draw();

		BitBlt(hDC, 0, 0, width, height, hBackDC, 0, 0, SRCCOPY);
		DeleteObject(backBitmap);
	}

	BOOL SceneManager::RegisterScene(LPCSTR sceneName, Scene* scene)
	{
		if ("" == sceneName || !scene || scenes.find(sceneName) != scenes.end()) return FALSE;
		scenes.insert(std::make_pair(sceneName, scene));
		return TRUE;
	}

	BOOL SceneManager::LoadScene(LPCSTR sceneName)
	{
		if ("" == sceneName || scenes.find(sceneName) == scenes.end())return FALSE;
		nextScene = sceneName;
		return TRUE;
	}

	HBITMAP SceneManager::CreateDIBSectionRe()
	{
		BITMAPINFO bmpInfo;
		ZeroMemory(&bmpInfo.bmiHeader, sizeof(BITMAPINFOHEADER));
		bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmpInfo.bmiHeader.biBitCount = 32;
		bmpInfo.bmiHeader.biWidth = width;
		bmpInfo.bmiHeader.biHeight = height;
		bmpInfo.bmiHeader.biPlanes = 1;
		LPVOID pBits;
		return CreateDIBSection(hDC, &bmpInfo, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	}
	
}