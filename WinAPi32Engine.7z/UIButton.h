#pragma once
#include "UIImage.h"

namespace ENGINE
{
	class UIButton : public UIImage
	{
		enum class ButtonState {NONE, HOVER , PRESSED};
	protected:
		EventListener clickListener, pressedListener;
		ButtonState state;
		BOOL isUp, isInteractable;
		Bitmap* normal, * pressed, * hover, * disable;

	public:
		UIButton();

		VOID Initialize(CONST std::string& normal, CONST std::string& pressed = "",
			CONST std::string& hover = "", CONST std::string& disable = "", DrawType type = DrawType::Normal);
		VOID SetListener(EventListener click, EventListener pressed = nullptr);
		VOID SetInteracterble(BOOL interactalbe) { isInteractable = interactalbe; };
		BOOL IsIteracterble() CONST { return isInteractable; };
		virtual VOID Update() override;
	};
}
