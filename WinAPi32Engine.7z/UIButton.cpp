
#include "UIButton.h"
#include "ResourceManager.h"
#include "InputManager.h"
namespace ENGINE
{
	UIButton::UIButton():clickListener(nullptr),pressedListener(nullptr),
		state(ButtonState::NONE),isUp(FALSE),isInteractable(TRUE),
		normal(nullptr),pressed(nullptr),hover(nullptr),disable(nullptr)
	{
		uiType = UIType::BUTTON;
	}
	VOID UIButton::Initialize(const std::string& normal, const std::string& pressed, CONST std::string& hover, const std::string& disable, DrawType type)
	{
		UIImage::Initialize(normal, type);
		this->disable = this->hover = this->pressed = this->normal = image;
		if (!pressed.empty()) this->pressed = ResourceMgr->GetBitmap(pressed);
		if (!hover.empty()) this->hover = ResourceMgr->GetBitmap(hover);
		if (!disable.empty()) this->disable = ResourceMgr->GetBitmap(disable);
	}
	VOID UIButton::SetListener(EventListener click, EventListener pressed)
	{
		clickListener = click;
		pressedListener = pressed;
	}
	VOID UIButton::Update()
	{
		if(!isEnable)
		return;
		UIImage::Update();

		if (!isInteractable)
		{
			state = ButtonState::NONE;
			if (disable) image = disable;
			return;
		}
		isUp = InputMgr->GetMouseButtonUp(VK_LBUTTON);
		if (PtInRect(&rect, InputMgr->GetMousePosition()))
		{
			switch (state)
			{
			case ENGINE::UIButton::ButtonState::NONE:
				state = ButtonState::HOVER;
			case ENGINE::UIButton::ButtonState::HOVER:
				if (InputMgr->GetMouseButtonDown(VK_LBUTTON)) state = ButtonState::PRESSED;
				break;
			case ENGINE::UIButton::ButtonState::PRESSED:
				if (isUp && clickListener)clickListener();
				break;
			default:
				break;
			}
		}
		else if (ButtonState::PRESSED != state) state = ButtonState::NONE;

		switch (state)
		{
		case ENGINE::UIButton::ButtonState::NONE:
			image = normal;
			break;
		case ENGINE::UIButton::ButtonState::HOVER:
			image = hover;
			break;
		case ENGINE::UIButton::ButtonState::PRESSED:
			image = pressed;
			if (isUp)
				state = ButtonState::NONE;
			if (pressedListener) pressedListener();
			break;
		default:
			break;
		}
	}
}

