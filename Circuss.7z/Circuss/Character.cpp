#include "Character.h"

Character::Character()
{
    m_iJumpDirection = 0;
    m_eDirection = MOVE_IDLE;
    m_Deltaime = PLAYER_WIN_ANIME_TIME;
    m_State = CHARACTER_STAND;
    m_bJump = false;
    m_iMovedLength = 0;
    m_iScore = 0;
    m_iLife = 0;
}


void Character::Init()
{
    m_pBitMap[CHARACTER_FRONT] = BitMapManager::GetInstance()->GetImage(IMAGE_PLAYER_3);
    m_pBitMap[CHARACTER_STAND] = BitMapManager::GetInstance()->GetImage(IMAGE_PLAYER_1);
    m_pBitMap[CHARACTER_BACK] = BitMapManager::GetInstance()->GetImage(IMAGE_PLAYER_2);
    m_pBitMap[CHARACTER_GOAL1] = BitMapManager::GetInstance()->GetImage(IMAGE_PLAYER_4);
    m_pBitMap[CHARACTER_GOAL2] = BitMapManager::GetInstance()->GetImage(IMAGE_PLAYER_5);
    m_pBitMap[CHARACTER_DEATH] = BitMapManager::GetInstance()->GetImage(IMAGE_PLAYER_6);
    m_ix = CHARACTER_START_X;
    m_iy = CHARACTER_MIN_Y;
    m_BitMapRect.left = m_ix;
    m_BitMapRect.top = m_iy;
    m_BitMapRect.right = m_BitMapRect.left + m_pBitMap[CHARACTER_STAND]->GetSize().cx;
    m_BitMapRect.bottom = m_BitMapRect.top + m_pBitMap[CHARACTER_STAND]->GetSize().cy;

    m_ScoreRect.left = m_BitMapRect.left;
    m_ScoreRect.right = m_BitMapRect.right;
    m_ScoreRect.top = 0;
    m_ScoreRect.bottom = m_BitMapRect.bottom;
    m_iLife = CHARACTER_MAX_LIFE;
    m_iScore = 0;

}

void Character::Draw(HDC hdc)
{
    m_pBitMap[m_State]->DrawTrans(hdc, m_ix, m_iy);
}


void Character::RectUpdate()
{
    m_BitMapRect.left = m_ix + 15;
    m_BitMapRect.top = m_iy ;
    m_BitMapRect.right = m_BitMapRect.left + m_pBitMap[CHARACTER_STAND]->GetSize().cx * PLAYER_CORRIDER_REDUCE;
    m_BitMapRect.bottom = m_BitMapRect.top + m_pBitMap[CHARACTER_STAND]->GetSize().cy * PLAYER_CORRIDER_REDUCE;

    m_ScoreRect.left = m_BitMapRect.left;
    m_ScoreRect.right = m_BitMapRect.right;
}

void Character::PlayerUpdate(float deltaTime)
{
    int x, y;

    if (m_bJump == true)
    {
        x = GetDistx(deltaTime);
        y = GetDisty(deltaTime);

        m_iy += y;

        if (m_iy <= CHARACTER_MAX_Y)
        {
            m_iJumpDirection = MOVE_DOWN;
            m_iy = CHARACTER_MAX_Y;
        }
        else if (m_iy >= CHARACTER_MIN_Y)
        {
            m_iJumpDirection = MOVE_IDLE;
            m_iy = CHARACTER_MIN_Y;
        }
        if (m_iJumpDirection == MOVE_IDLE)
        {
            m_bJump = false;
        }
    }

    RectUpdate();
}

void Character::SetPos(int x, int y)
{
    m_iy = y;
    m_ix = x;
}


void Character::Reset()
{
    m_iLife = CHARACTER_MAX_LIFE;
    m_iScore = 0;
    Undo();
}

void Character::Undo()
{
    m_iMovedLength = 0;
    m_iJumpDirection = 0;
    m_ix = CHARACTER_START_X;
    m_iy = CHARACTER_MIN_Y;
    m_bJump = false;

    m_eDirection = MOVE_IDLE;
    m_State = CHARACTER_STAND;
}

void Character::UpdatePosx(int x)
{
    m_ix += x;
}

void Character::SetJump()
{
    m_bJump = true;
    m_iJumpDirection = MOVE_UP;
}
bool Character::IsJump()
{
    return m_bJump;
}

int Character::GetDistx(float deltaTime)
{
     return m_eDirection * CHARACTER_SPEED * deltaTime;
}
int Character::GetDisty(float deltaTime)
{
    return m_iJumpDirection * CHARACTER_JUMP_SPEED * deltaTime;
}
void Character::SetDirection(MOVE dir)
{
    m_eDirection = dir;
}

void Character::AnimationChange()
{
    if (m_bJump == true)
    {
        m_State = CHARACTER_FRONT;
    }
    else
    {
        switch (m_State)
        {
        case CHARACTER_STAND:
            if (m_eDirection == MOVE_LEFT)
                m_State = CHARACTER_BACK;
            else if (m_eDirection == MOVE_RIGHT)
                m_State = CHARACTER_FRONT;
            break;
        default:
            m_State = CHARACTER_STAND;
        }
    }
   
}

void Character::PlusScore(int iScore)
{
    m_iScore += iScore;
}

const int* Character::GetLife()
{
    return &m_iLife;
}

int* Character::GetScore()
{
    return &m_iScore;
}

RECT Character::GetRect()
{
    return m_BitMapRect;
}

RECT Character::GetScoreRect()
{
    return m_ScoreRect;
}

Character::~Character()
{
}

void Character::SetStateDeath()
{
    m_iLife--;
    m_State = CHARACTER_DEATH;
}
void Character::GOALAnimaition(float deltaTime)
{
    m_Deltaime += deltaTime;
    if (m_Deltaime >= PLAYER_WIN_ANIME_TIME)
    {
        m_Deltaime = 0;
        if (m_State == CHARACTER_GOAL1)
            m_State = CHARACTER_GOAL2;
        else
            m_State = CHARACTER_GOAL1;
    }
}
