#include "FireRing.h"

void FireRing::Init()
{
	m_pBitMap[FIRE_RING_1] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_1);
	m_pBitMap[FIRE_RING_2] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_2);
	m_pBitMap[FIRE_RING_3] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_3);
	m_pBitMap[FIRE_RING_4] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_4);

	m_iy = RING_HEIGHT;

	m_BitMapRect.left = m_ix;
	m_BitMapRect.top = m_iy + (m_pBitMap[FIRE_RING_1]->GetSize().cy * FIRERING_HEIGHT);
	m_BitMapRect.right = m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx * 2;
	m_BitMapRect.bottom = m_iy + m_pBitMap[FIRE_RING_1]->GetSize().cy;
	m_ScoreCheck = true;
}

void FireRing::UpdateRing(float deltaTime)
{
	m_ix -= (FIRE_RING_SPEED * deltaTime);
	AnimationSwitch(deltaTime);
}


void  FireRing::RectUpdate()
{
	m_BitMapRect.left = m_ix + RING_WIDTH;
	m_BitMapRect.right = (m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx * 2) - RING_WIDTH;
}

void FireRing::ObstacleDraw(HDC hdc)
{
	if (m_bAnim)
	{
		m_pBitMap[FIRE_RING_2]->DrawTrans(hdc, m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx, m_iy);
	}
	else
	{
		m_pBitMap[FIRE_RING_4]->DrawTrans(hdc, m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx, m_iy);
	}
	RectUpdate();
}


void FireRing::ObstacleFrontDraw(HDC hdc)
{
	if (m_bAnim)
	{
		m_pBitMap[FIRE_RING_1]->DrawTrans(hdc, m_ix, m_iy);
	}
	else
	{
		m_pBitMap[FIRE_RING_3]->DrawTrans(hdc, m_ix, m_iy);
	}
	RectUpdate();
}