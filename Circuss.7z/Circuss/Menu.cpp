#include "Menu.h"

Menu::Menu()
{
	m_deltaTime = 0;
	m_Point_y = MENU::MENU_PLAYER1_A;
}

Menu::~Menu()
{
}

void Menu::CreateStar()
{
	char color = 0;
	int i = 0;
	int Star_size_x = BitMapManager::GetInstance()->GetImage(IMAGE_TITLE_2)->GetSize().cx;
	int Star_size_y = BitMapManager::GetInstance()->GetImage(IMAGE_TITLE_2)->GetSize().cy;

	int Half_Width_num = STAR_WIDTH_NUM * 0.5f;//����
	int Start_x = m_iMiddleSort - Star_size_x * Half_Width_num;
	int End_x = m_iMiddleSort + Star_size_x * Half_Width_num;

	int Start_y = STAR_POS_Y - Star_size_y;
	int End_y = STAR_POS_Y + Star_size_y * (STAR_HEIGHT_NUM);

	for (int x = 0; x < STAR_WIDTH_NUM; x++, color++, i++)
	{
		if (color > COLOR_YELLOW)
			color = 0;

		m_star[i].Init((COLOR)(color), Start_x + ((x) *Star_size_x), Start_y);
		
	}
	for (int y = 0; y < STAR_HEIGHT_NUM; y++, color++, i++)
	{
		if (color > COLOR_YELLOW)
			color = 0;

		m_star[i].Init((COLOR)(color), End_x, STAR_POS_Y + (y * Star_size_y));
	}
	for (int x = 0; x < STAR_WIDTH_NUM; x++, color++, i++)
	{
		if (color > COLOR_YELLOW)
			color = 0;

		m_star[i].Init((COLOR)(color), Start_x + ((x) *Star_size_x), End_y);
	}
	for (int y = 0; y < STAR_HEIGHT_NUM; y++, color++, i++)
	{
		if (color > COLOR_YELLOW)
			color = 0;

		m_star[i].Init((COLOR)(color), Start_x - Star_size_x, STAR_POS_Y + (y * Star_size_y));
	}
}


void Menu::Init(RECT windowRect)
{
	int index;

	m_iMiddleSort = ((windowRect.right - windowRect.left) * 0.5f);

	for (int i = MENU_SELECT; i <= MENU_PLAYER2_B; i++)
	{
		index = i - MENU_SELECT;
		m_pBitMap[i] = BitMapManager::GetInstance()->GetImage((IMAGE)(index + IMAGE_MENU_1));
	}
	m_pBitMap[MENU_POINT] = BitMapManager::GetInstance()->GetImage(IMAGE_POINT);
	m_pBitMap[MENU_TITLE1] = BitMapManager::GetInstance()->GetImage(IMAGE_TITLE_1);
	m_Point_y = MENU_PLAYER1_A;

	CreateStar();
}

void Menu::Draw(HDC hdc)
{
	DrawStar(hdc);
	DrawMenu(hdc);
	DrawPoint(hdc);
}

void Menu::Update(float deltaTime,int Move)
{

	if (m_Point_y + Move >= MENU_PLAYER1_A && m_Point_y + Move <= MENU_PLAYER2_B)
		m_Point_y += Move;
	m_deltaTime += deltaTime;
	while (0.2f <= m_deltaTime)
	{
		m_deltaTime = 0;
		ChangeStar();
	}
}

void Menu::DrawStar(HDC hdc)
{
	/*for (Star& s : m_star)
	{
		s.DrawStar(hdc);
	}*/
	for (int i = 0; i < STAR_NUM; i++)
	{
		m_star[i].DrawStar(hdc);
	}
}

void Menu::ChangeStar()
{

	for (int i = 0; i < STAR_NUM; i++)
	{
		m_star[i].ChangeStarColor();
	}
}
void Menu::DrawMenu(HDC hdc)
{
	int tmp = m_iMiddleSort - m_pBitMap[MENU_TITLE1]->GetSize().cx * 0.5f;
	m_pBitMap[MENU_TITLE1]->DrawTrans(hdc, tmp, MENU_TEXT_POS_Y);

	tmp = m_iMiddleSort - m_pBitMap[MENU_SELECT]->GetSize().cx * 0.5f;
	m_pBitMap[MENU_SELECT]->DrawTrans(hdc, tmp, MENU_TEXT_POS_Y*2);

	tmp = m_iMiddleSort - m_pBitMap[MENU_PLAYER1_A]->GetSize().cx * 0.5f;
	for (int i = MENU_PLAYER1_A; i <= MENU_PLAYER2_B; i++)
	{
		m_pBitMap[i]->DrawTrans(hdc, tmp, MENU_TEXT_POS_Y * 2 + MENU_TEXT_POS_Y_INTER * i);
	}
}

void Menu::DrawPoint(HDC hdc)
{
	m_pBitMap[MENU_POINT]->DrawTrans(hdc, m_iMiddleSort - MENU_PONIT_POS_X, MENU_TEXT_POS_Y*2 + m_Point_y * MENU_TEXT_POS_Y_INTER);
}