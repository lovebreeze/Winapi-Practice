#include "Fire.h"

void Fire::Init()
{
	m_pBitMap[FIRE_1] = BitMapManager::GetInstance()->GetImage(IMAGE_FIRE_1);
	m_pBitMap[FIRE_2] = BitMapManager::GetInstance()->GetImage(IMAGE_FIRE_2);

	m_iy = FIRE_HEIGHT;

	m_BitMapRect.left = m_ix;
	m_BitMapRect.top = m_iy;
	m_BitMapRect.right = m_ix + m_pBitMap[FIRE_1]->GetSize().cx;
	m_BitMapRect.bottom = m_iy + m_pBitMap[FIRE_1]->GetSize().cy;
	m_ScoreCheck = true;
}

void Fire::RectUpdate()
{
	m_BitMapRect.left = m_ix;
	m_BitMapRect.right = m_ix + m_pBitMap[FIRE_1]->GetSize().cx;
}
void Fire::ObstacleDraw(HDC hdc)
{
	if (m_bAnim)
		m_pBitMap[FIRE_1]->DrawTrans(hdc, m_ix, m_iy);
	else
		m_pBitMap[FIRE_2]->DrawTrans(hdc, m_ix, m_iy);
	RectUpdate();
}