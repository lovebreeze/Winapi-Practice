#include "Obstaclee.h"

Obstaclee::Obstaclee()
{
	m_ix = 0;
	m_iy = 0;
	m_DeltaTime = 0;
	m_bAnim = true;
	m_ScoreCheck = true;
}
Obstaclee::~Obstaclee()
{
}

void Obstaclee::UpdateObstacle(int x, float deltaTime)
{
	m_ix -= x;
	Update();
	AnimationSwitch(deltaTime);
}

void Obstaclee::SetX(int x)
{
	m_ix = x;
}

bool Obstaclee::ColliderCheck(Character* Player)
{
	RECT player = Player->GetRect();
	RECT tmp;
	if (IntersectRect(&tmp, &m_BitMapRect, &player))
	{
		return true;
	}
	else
		return false;
}
void Obstaclee::ColliderCheck_Score(Character* Player)
{
	if (m_ScoreCheck)
	{
		RECT player = Player->GetScoreRect();
		RECT tmp;
		if (IntersectRect(&tmp, &m_BitMapRect, &player))
		{
			Player->PlusScore(OBSTACLE_SCORE);
			m_ScoreCheck = false;
		}
	}
}

void Obstaclee::AnimationSwitch(float deltaTime)
{
	m_DeltaTime += deltaTime;
	if (m_DeltaTime >= 0.2f)
	{
		m_DeltaTime = 0;
		if (m_bAnim)
			m_bAnim = false;
		else
			m_bAnim = true;
	}
}
int Obstaclee::GetX()
{
	return m_ix;
}

void Obstaclee::Update()
{
	if (m_ix <= OBSTACLE_END_X) // ��ֹ� ��ġ �缳��
	{
		m_ix = OBSTACLE_START_X;
		m_ScoreCheck = true;
	}

	RectUpdate();
}
