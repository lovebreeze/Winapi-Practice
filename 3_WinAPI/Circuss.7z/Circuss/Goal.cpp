#include "Goal.h"

	void Goal::Init()
	{
		m_pBitMap = BitMapManager::GetInstance()->GetImage(IMAGE_GOAL);
		m_ix = GOAL_POS_X;
		m_iy = GOAL_HEIGHT;
		m_BitMapRect.left = m_ix;
		m_BitMapRect.top = m_iy;
		m_BitMapRect.right = m_ix + m_pBitMap->GetSize().cx;
		m_BitMapRect.bottom = m_iy + m_pBitMap->GetSize().cy;
	}
	void Goal::Undo(int value)
	{
		m_ix += value;
	}
	void Goal::SetPlayerGoal(Character* Player)
	{
		Player->SetPos(m_ix, m_iy - m_pBitMap->GetSize().cy - 10);
	}
	void Goal::RectUpdate()
	{
		m_BitMapRect.left = m_ix;
		m_BitMapRect.right = m_ix + m_pBitMap->GetSize().cx;
	}

	void Goal::ObstacleDraw(HDC hdc)
	{
		m_pBitMap->DrawTrans(hdc, m_ix, m_iy);
		RectUpdate();
	}