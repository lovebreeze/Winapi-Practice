#pragma once
#include "Obstaclee.h"

enum FIRE
{
	FIRE_1,
	FIRE_2,
	FIRE_END
};
 
class Fire :public Obstaclee
{
private:
	BitMap* m_pBitMap[FIRE_END];
	FIRE anim;

public:
	//�ʱ�ȭ
	virtual void Init();
	//�浹�ڽ�������Ʈ
	virtual void RectUpdate();
	//�׸���
	virtual void ObstacleDraw(HDC hdc);
};

