#include "ObstacleManager.h"

ObstacleManager* ObstacleManager::m_hThis = NULL;

void ObstacleManager::Init()
{
	InitObtacle();
	m_goal.Init();
}
void ObstacleManager::Undo(int value)
{
	InitObtacle();
	m_goal.Undo(value);
}
void ObstacleManager::InitObtacle()
{
	for (int i = 0; i < FIRE_NUM; i++)
	{
		m_FireRing[i].Init();
		m_FireRing[i].SetX(500 + 1000 * i);
	}
	for (int i = 0; i < FIRE_NUM; i++)
	{
		m_fire[i].Init();
		m_fire[i].SetX(600 + 1000 * i);
	}
	m_SmallRing.Init();
	m_SmallRing.SetX(1500);
}

void ObstacleManager::DrawObstacle(HDC hdc)
{
	for (int i = 0; i < FIRE_NUM; i++)
		m_fire[i].ObstacleDraw(hdc);
	m_goal.ObstacleDraw(hdc);

	for (int i = 0; i < FIRE_NUM; i++)
		m_FireRing[i].ObstacleDraw(hdc);
	m_SmallRing.ObstacleDraw(hdc);
}

void ObstacleManager::DrawRingFrontObstacle(HDC hdc)
{
	for (int i = 0; i < FIRE_NUM; i++)
		m_FireRing[i].ObstacleFrontDraw(hdc);
	m_SmallRing.ObstacleFrontDraw(hdc);
}

void ObstacleManager::UpdateObstacle(int x, float deltaTime)
{
	for (int i = 0; i < FIRE_NUM; i++)
		m_FireRing[i].UpdateObstacle(x, deltaTime);
	for (int i = 0; i < FIRE_NUM; i++)
		m_fire[i].UpdateObstacle(x, deltaTime);
	m_goal.UpdateObstacle(x, deltaTime);
	m_SmallRing.UpdateObstacle(x, deltaTime);
}
void ObstacleManager::UpdateAnimation(float deltaTime)
{
	for (int i = 0; i < FIRE_NUM; i++)
		m_FireRing[i].AnimationSwitch(deltaTime);
	for (int i = 0; i < FIRE_NUM; i++)
		m_fire[i].AnimationSwitch(deltaTime);
	m_SmallRing.AnimationSwitch(deltaTime);
}
bool ObstacleManager::ColliderCheck_Obstacle(Character* Player)
{
	for (int i = 0; i < FIRE_NUM; i++)
	{
		if (m_FireRing[i].ColliderCheck(Player))
			return true;
	}
	for (int i = 0; i < FIRE_NUM; i++)
	{
		if (m_fire[i].ColliderCheck(Player))
			return true;
	}
	if (m_SmallRing.ColliderCheck(Player))
		return true;

	return false;
}
void ObstacleManager::ColliderCheck_Score(Character* Player)
{
	for (int i = 0; i < FIRE_NUM; i++)
	{
		m_FireRing[i].ColliderCheck_Score(Player);
	}
	for (int i = 0; i < FIRE_NUM; i++)
	{
		m_fire[i].ColliderCheck_Score(Player);
	}
	m_SmallRing.ColliderCheck_Score(Player);

}
bool ObstacleManager::ColliderCheck_GOAL(Character* Player)
{
	if (m_goal.ColliderCheck(Player))
	{
		m_goal.SetPlayerGoal(Player);
		return true;
	}

	return false;
}
void ObstacleManager::UpdateRing(float deltatime)
{
	for (int i = 0; i < FIRE_NUM; i++)
		m_FireRing[i].UpdateRing(deltatime);
	m_SmallRing.UpdateRing(deltatime);
}