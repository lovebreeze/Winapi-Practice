#include "Map.h"

Map::Map()
{
	m_imoveLen = 0;
	m_ix = 0; 
	m_iMaxMapDraw = 0; 
	m_iBonusScore = BONUSSCORE_MAX;
	m_iScore = 0; 
	m_deltaTime = 0; 
	iTotalScore = 0;
	m_bAnim = false; 
	m_bGoal = false;
}

void Map::Init(int width, const int* life, int* Score)
{
	m_pBitMap[BACKGROUND_TRACK] = BitMapManager::GetInstance()->GetImage(IMAGE_BACK_1);
	m_pBitMap[BACKGROUND_BACK1] = BitMapManager::GetInstance()->GetImage(IMAGE_BACK_2);
	m_pBitMap[BACKGROUND_BACK2] = BitMapManager::GetInstance()->GetImage(IMAGE_BACK_3);
	m_pBitMap[BACKGROUND_BACK3] = BitMapManager::GetInstance()->GetImage(IMAGE_BACK_4);
	m_pBitMap[BACKGROUND_GOAL] = BitMapManager::GetInstance()->GetImage(IMAGE_GOAL);
	m_pBitMap[BACKGROUND_INTERFACE] = BitMapManager::GetInstance()->GetImage(IMAGE_INTERFACE_1);
	m_pBitMap[BACKGROUND_LIFE] = BitMapManager::GetInstance()->GetImage(IMAGE_INTERFACE_2);
	m_pBitMap[BACKGROUND_METER] = BitMapManager::GetInstance()->GetImage(IMAGE_INTERFACE_3);

	m_BackBitmapSize_x = m_pBitMap[BACKGROUND_BACK1] -> GetSize().cx;
	m_BackBitmapSize_y = m_pBitMap[BACKGROUND_BACK1]->GetSize().cy;

	m_ix = 0;
	m_iy = 0;
	m_iMaxMapDraw = (width) / m_BackBitmapSize_x + 2;
																	// �� �ڷ� ��� �ϳ��� �� �׸����� + 2�� 

	m_iLife = life;
	m_iScore = Score;
	for (int i = 0; i <= m_iMaxMapDraw; i++)
	{
		if (i == 8  || i== 20) //8���� 20��° ��濡�� �ٸ� �׸� �ֱ�
			m_BackGroundVec.push_back(BACKGROUND_BACK1);
		else
			m_BackGroundVec.push_back(BACKGROUND_BACK2);
	}
														//����
	m_iMiddleSort = ((width) * 0.5f) - (m_pBitMap[BACKGROUND_INTERFACE]->GetSize().cx * 0.5f);
}

void Map::Update(float deltaTime)
{
	if (!m_bGoal)
	{
		--m_iBonusScore;
	}
	else
	{
		m_deltaTime += deltaTime;
		if (0.5f <= m_deltaTime)
		{
			m_deltaTime = 0;
			if (!m_bAnim)
				m_bAnim = true;
			else
				m_bAnim = false;
		}
	}
	
	
}

void Map::MapDraw(HDC hdc)
{
	char buf[256];
	std::string str_tmp;

	//������ �׸���
	m_pBitMap[BACKGROUND_INTERFACE]->DrawTrans(hdc, m_iMiddleSort, 20);
	SetTextColor(hdc, RGB(255, 255, 255));
	SetBkColor(hdc, RGB(0, 0, 0));
	if (m_bGoal) //������ �����϶� 
	{
		

		if (*m_iScore<=0&&m_iBonusScore <= 0)
		{
			sprintf_s(buf, "! ! �� �� ! !       ");
			TextOutA(hdc, m_iMiddleSort + SCORETEXT_POS_X, SCORETEXT_POS_Y, buf, strlen(buf));
		}
		else
		{
			sprintf_s(buf, "Score : %d", *m_iScore);
			TextOutA(hdc, m_iMiddleSort + SCORETEXT_POS_X, SCORETEXT_POS_Y, buf, strlen(buf));
			sprintf_s(buf, "BonusScore : %d", m_iBonusScore);
			TextOutA(hdc, m_iMiddleSort + SCORETEXT_POS_X * 2, SCORETEXT_POS_Y, buf, strlen(buf));
			ScoreCalculation();
		}
		sprintf_s(buf, "TotalScore : %d  ", iTotalScore);
		TextOutA(hdc, m_iMiddleSort+ SCORETEXT_POS_X * 3, SCORETEXT_POS_Y, buf, strlen(buf));
	}
	else //�� ���� �����϶�
	{
		sprintf_s(buf, "Score : %d", *m_iScore);
		TextOutA(hdc, m_iMiddleSort + SCORETEXT_POS_X, SCORETEXT_POS_Y, buf, strlen(buf));
		sprintf_s(buf, "BonusScore : %d", m_iBonusScore);
		TextOutA(hdc, m_iMiddleSort + SCORETEXT_POS_X * 2, SCORETEXT_POS_Y, buf, strlen(buf));
	}

	int lifesize = m_pBitMap[BACKGROUND_LIFE]->GetSize().cx;
	for (int i = 0; i < *m_iLife; i++)//��� ������ �׸���
	{
		m_pBitMap[BACKGROUND_LIFE]->DrawTrans(hdc, m_iMiddleSort+ SCORETEXT_POS_X * 4 + i * lifesize, SCORETEXT_POS_Y+10);
	}

	for (int i = 0; i < MITER_SIZE; i++)//����ǥ���� �׸���
	{
		str_tmp = std::to_string(MITER_MAX -i* MITER_INTER);
		m_pBitMap[BACKGROUND_METER]->Draw(hdc, MITER * i - m_imoveLen, MITER_POS_Y);
		TextOutA(hdc, 20 + MITER * i - m_imoveLen, MITER_POS_Y +5, str_tmp.c_str(), strlen(str_tmp.c_str()));
	}

	int x = -m_BackBitmapSize_y;
	for (auto iter : m_BackGroundVec) // ��� �׸���
	{
		m_iy = BACK_POS_Y;
		if (iter == BACKGROUND_BACK1)
		{
			m_pBitMap[BACKGROUND_BACK1]->Draw(hdc, m_ix + x, m_iy);
		}
		else
		{
			if (m_bGoal == true && m_bAnim == true) //���ѻ��¸鼭 �ִϸ��̼� �����϶�
				m_pBitMap[BACKGROUND_BACK3]->Draw(hdc, m_ix + x, m_iy);
			else
				m_pBitMap[BACKGROUND_BACK2]->Draw(hdc, m_ix + x, m_iy);
		}

		m_iy += m_BackBitmapSize_y;
		m_pBitMap[BACKGROUND_TRACK]->Draw(hdc, m_ix + x, m_iy);

		x += m_BackBitmapSize_x;
	}

}

void Map::ScoreCalculation()
{
	if (*m_iScore >= 100)
	{
		*m_iScore -= 100;
		iTotalScore += 100;
	}

	if (m_iBonusScore >= 100)
	{
		m_iBonusScore -= 100;
		iTotalScore += 100;
	}
	else if (m_iBonusScore >= 10)
	{
		m_iBonusScore -= 10;
		iTotalScore += 10;
	}
	else if (m_iBonusScore >= 1)
	{
		m_iBonusScore -= 1;
		iTotalScore += 1;
	}

}

void Map::Reset()
{
	iTotalScore = 0;
	m_iBonusScore = BONUSSCORE_MAX;
	m_imoveLen = 0;
	m_ix = 0;
	m_bGoal = false;
}

void Map::SetGoal()
{
	m_bGoal = true;
}

int Map::GetMoveLenx()
{
	return m_imoveLen;
}
void Map::UpdateMoveLenx(int x)
{
	m_imoveLen += x;
	m_ix -= x;
	if (m_imoveLen < 0)
	{
		m_imoveLen -= x;
		m_ix += x;
	}


	BACKGROUND tmp ;

	//����� �����ĭ��ŭ ���̳� �ڷ� �̵������� vector ������
	if (m_ix < -m_BackBitmapSize_x )
	{
		tmp = m_BackGroundVec[0];
		for (int i = 0; i < m_BackGroundVec.size() - 1; ++i)
		{
			m_BackGroundVec[i] = m_BackGroundVec[i + 1];
		}
		m_BackGroundVec.back() = tmp;

		m_ix += m_BackBitmapSize_x;
	}
	else if (m_ix > m_BackBitmapSize_x)
	{
		tmp = m_BackGroundVec[m_BackGroundVec.size()-1];
		for (int i = m_BackGroundVec.size() - 1; i > 0; --i)
		{
			m_BackGroundVec[i] = m_BackGroundVec[i - 1];
		}
		m_BackGroundVec[0] = tmp;

		m_ix -= m_BackBitmapSize_x;
	}
}

int Map::Undo()
{
	int value = m_imoveLen - ((m_imoveLen / MITER) * MITER);
	m_imoveLen -= value;
	return value;
}

Map::~Map()
{

}