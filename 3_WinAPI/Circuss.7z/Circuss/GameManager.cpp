#include "GameManager.h"

GameManager* GameManager::m_hThis = NULL;

GameManager::GameManager()
{

}
void GameManager::Init(HWND hWnd)
{
	m_hWnd = hWnd;
	hdc = GetDC(m_hWnd);
	backDC = CreateCompatibleDC(hdc);
	RECT windowRect;
	GetWindowRect(m_hWnd, &windowRect);
	width = windowRect.right - windowRect.left;
	height = windowRect.bottom - windowRect.top;


	BitMapManager::GetInstance()->Init(hdc);
	ObstacleManager::GetInstance()->Init();
	m_menu.Init(width);
	m_Player.Init();
	m_BackGround.Init(width, m_Player.GetLife(), m_Player.GetScore());
	m_Mode = IN_MENU;
	m_Deltaime = 0;
	MoveDirection = 0;

}
GameManager::~GameManager()
{
	DeleteObject(backDC);
	ReleaseDC(m_hWnd, hdc);
}
void GameManager::Update(float deltaTime)
{

	int player_x = m_Player.GetDistx(deltaTime);
	int ran;

	switch (m_Mode)
	{
	case IN_MENU:
		MoveDirection = 0;
		m_Deltaime -= deltaTime;
		if (m_Deltaime <= 0)
		{
			if (GetAsyncKeyState(VK_UP))
			{
				MoveDirection = MOVE_UP;
				m_Deltaime = MENU_TIME;
			}
			else if (GetAsyncKeyState(VK_DOWN))
			{
				MoveDirection = MOVE_DOWN;
				m_Deltaime = MENU_TIME;
			}
		}
		if (GetAsyncKeyState(VK_RETURN))
		{
			m_Mode = IN_GAME;
			m_Deltaime = 0;
		}
		m_menu.Update(deltaTime, MoveDirection);
		break;
	case IN_GAME:
		player_x = m_Player.GetDistx(deltaTime);
		if (!m_Player.IsJump())
		{
			if (GetAsyncKeyState(VK_RIGHT))
			{
				m_Player.SetDirection(MOVE_RIGHT);
			}
			else if (GetAsyncKeyState(VK_LEFT))
			{
				m_Player.SetDirection(MOVE_LEFT);
			}
			else
			{
				m_Player.SetDirection(MOVE_IDLE);
			}

			if (GetAsyncKeyState(VK_SPACE))
			{
					m_Player.SetJump();
			}
		}

		m_Player.PlayerUpdate(deltaTime);
		m_Deltaime += deltaTime;
		if (m_Deltaime >= PLAYER_MOVE_ANIME_TIME)
		{
			m_Player.AnimationChange();
			m_Deltaime = 0;
		}

		if (ObstacleManager::GetInstance()->ColliderCheck_GOAL(&m_Player))
			m_Mode = GOAL;
		else if (ObstacleManager::GetInstance()->ColliderCheck_Obstacle(&m_Player))
		{
			m_Mode = DEATH;
			m_Player.SetStateDeath();
			m_Deltaime = 0;
		}

		ObstacleManager::GetInstance()->ColliderCheck_Score(&m_Player);

		if (m_BackGround.GetMoveLenx() >= FINISH_LINE)
		{
			m_Player.UpdatePosx(player_x);
			ObstacleManager::GetInstance()->UpdateAnimation(deltaTime);
			if (player_x < 0&& m_Player.GetX()<=50)
				m_BackGround.UpdateMoveLenx(player_x);
		}
		else 
		{
			m_BackGround.UpdateMoveLenx(player_x);
			if(m_BackGround.GetMoveLenx()>0)
			ObstacleManager::GetInstance()->UpdateObstacle(player_x, deltaTime);
		}
		m_BackGround.Update(deltaTime);
		ObstacleManager::GetInstance()->UpdateRing(deltaTime);

		break;
	case DEATH:

		m_Deltaime += deltaTime;
		if (m_Deltaime > DEATH_TIME)
		{
			int value = m_BackGround.Undo();
			int Life = *m_Player.GetLife();

			if (Life==1)
			{
				m_Mode = IN_MENU;
				m_Player.Reset();
				m_BackGround.Reset();
				ObstacleManager::GetInstance()->Init();
			}
			else
			{
				m_Player.Undo();
				m_Mode = IN_GAME;
				ObstacleManager::GetInstance()->Undo(value);;
			}
			m_Deltaime = 0;
		}
		break;

	case GOAL:
		m_BackGround.Update(deltaTime);
		m_Player.GOALAnimaition(deltaTime);
		m_BackGround.SetGoal();
		m_Deltaime += deltaTime;
		if (m_Deltaime > WIN_TIME)
		{
			m_Deltaime = 0;
			m_Mode = IN_MENU;
			m_Player.Reset();
			m_BackGround.Reset();
			ObstacleManager::GetInstance()->Init();
		}

		break;
	}
}
void GameManager::DoubleBuffer()
{
	HBITMAP backBitmap = CreateDIBSectionRe(hdc, width, height);
	
	SelectObject(backDC, backBitmap);

	switch (m_Mode)
	{
	case IN_MENU:
		m_menu.Draw(backDC);
		break;
	case IN_GAME:
	case DEATH:
	case GOAL:
		m_BackGround.MapDraw(backDC);
		ObstacleManager::GetInstance()->DrawRingFrontObstacle(backDC);
		m_Player.Draw(backDC);
		ObstacleManager::GetInstance()->DrawObstacle(backDC);
		break;
	default:
		break;
	}

	BitBlt(hdc, 0, 0, width, height, backDC, 0, 0, SRCCOPY);

	DeleteObject(backBitmap);
}

HBITMAP GameManager::CreateDIBSectionRe(HDC hdc, int width, int height)
{
	BITMAPINFO bm_info;
	ZeroMemory(&bm_info.bmiHeader, sizeof(BITMAPINFOHEADER));
	bm_info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bm_info.bmiHeader.biBitCount = 24; // �÷� ��(color bits) : 1, 4, 8, 16, 24, 31
	bm_info.bmiHeader.biWidth = width; // �ʺ�.
	bm_info.bmiHeader.biHeight = height;// ����.
	bm_info.bmiHeader.biPlanes = 1;
	LPVOID pBits;
	return CreateDIBSection(hdc, &bm_info, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
}

