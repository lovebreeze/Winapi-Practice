#include "Star.h"


void Star::Init(COLOR color, int x, int y)
{
	m_color = color;
	m_ix = x;
	m_iy = y;
	SetBitMap();
}
void Star::SetBitMap()
{
	switch (m_color)
	{
	case COLOR_BLUE:
		m_pBitMap = BitMapManager::GetInstance()->GetImage(IMAGE_TITLE_2);
		break;
	case COLOR_RED:
		m_pBitMap = BitMapManager::GetInstance()->GetImage(IMAGE_TITLE_3);
		break;
	case COLOR_YELLOW:
		m_pBitMap = BitMapManager::GetInstance()->GetImage(IMAGE_TITLE_4);
		break;
	}
}

void Star::DrawStar(HDC hdc)
{
	m_pBitMap->DrawTrans(hdc, m_ix, m_iy);
}

void Star::ChangeStarColor()
{
	switch (m_color)
	{
	case COLOR_BLUE:
	case COLOR_RED:
		m_color++;
		break;
	case COLOR_YELLOW:
		m_color = COLOR_BLUE;
		break;
	}
	SetBitMap();
}