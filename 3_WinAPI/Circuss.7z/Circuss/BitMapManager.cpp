
#include "BitMapManager.h"

BitMapManager* BitMapManager::m_hThis = NULL;

BitMapManager::BitMapManager()
{
	/*
	m_parrBitMap = new BitMap[IMAGE_END];*/
}


void BitMapManager::Init(HDC hdc)
{
	char buf[256];
	BitMap* New_BitMap;
	for (int i = IMAGE_START; i <= IMAGE_TITLE_4; i++)
	{
		switch (i)
		{
		case IMAGE_BACK_1:
		case IMAGE_BACK_2:
		case IMAGE_BACK_3:
		case IMAGE_BACK_4:
			sprintf(buf, "Image//back_%d.bmp", i);
			break;
		case IMAGE_CASH:
			sprintf(buf, "Image//cash.bmp");
			break;
		case IMAGE_BLACK:
			sprintf(buf, "Image//black.bmp");
			break;
		case IMAGE_FIRE_1:
		case IMAGE_FIRE_2:
			sprintf(buf, "Image//fire_%d.bmp", i - (IMAGE_FIRE_1 - 1));
			break;
		case IMAGE_GOAL:
			sprintf(buf, "Image//goal.bmp");
			break;
		case IMAGE_INTERFACE_1:
		case IMAGE_INTERFACE_2:
		case IMAGE_INTERFACE_3:
			sprintf(buf, "Image//interface_%d.bmp", i - (IMAGE_INTERFACE_1 - 1));
			break;
		case IMAGE_MENU_1:
		case IMAGE_MENU_2:
		case IMAGE_MENU_3:
		case IMAGE_MENU_4:
		case IMAGE_MENU_5:
			sprintf(buf, "Image//menu_%d.bmp", i - (IMAGE_MENU_1 - 1));
			break;
		case IMAGE_PLAYER_1:
		case IMAGE_PLAYER_2:
		case IMAGE_PLAYER_3:
		case IMAGE_PLAYER_4:
		case IMAGE_PLAYER_5:
		case IMAGE_PLAYER_6:
			sprintf(buf, "Image//player_%d.bmp", i - (IMAGE_PLAYER_1 - 1));
			break;
		case IMAGE_POINT:
			sprintf(buf, "Image//point.bmp");
			break;
		case IMAGE_RING_1:
		case IMAGE_RING_2:
		case IMAGE_RING_3:
		case IMAGE_RING_4:
			sprintf(buf, "Image//ring_%d.bmp", i - (IMAGE_RING_1 - 1));
			break;
		case IMAGE_TITLE_1:
		case IMAGE_TITLE_2:
		case IMAGE_TITLE_3:
		case IMAGE_TITLE_4:
			sprintf(buf, "Image//title_%d.bmp", i - (IMAGE_TITLE_1 - 1));
			break;

		default:
			break;
		}
		New_BitMap = new BitMap;
		New_BitMap->Init(hdc, buf);
		m_parrBitMap.push_back(New_BitMap);
	}

}

BitMapManager::~BitMapManager()
{
	for (auto iter : m_parrBitMap)
	{
		delete iter;
	}
}
