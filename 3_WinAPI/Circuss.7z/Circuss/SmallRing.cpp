#include "SmallRing.h"

void SmallRing::Init()
{
	//FireRing::Init();
	m_ScoreCheck = true;

	m_pBitMap[FIRE_RING_1] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_1);
	m_pBitMap[FIRE_RING_2] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_2);
	m_pBitMap[FIRE_RING_3] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_3);
	m_pBitMap[FIRE_RING_4] = BitMapManager::GetInstance()->GetImage(IMAGE_RING_4);
	m_iy = RING_HEIGHT;

	m_BitMapRect.left = m_ix;
	m_BitMapRect.top = m_iy + (m_pBitMap[FIRE_RING_1]->GetSize().cy * FIRERING_HEIGHT * SMALLRING_SIZE);
	m_BitMapRect.right = m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx * 2;
	m_BitMapRect.bottom = m_iy + m_pBitMap[FIRE_RING_1]->GetSize().cy * SMALLRING_SIZE;

	m_pBitMapGold = BitMapManager::GetInstance()->GetImage(IMAGE_CASH);
	m_iCashY = RING_HEIGHT + 10;

	m_BitMapCashRect.top = m_iCashY;
	m_BitMapCashRect.bottom = m_iCashY + m_pBitMapGold->GetSize().cy ;

}

void SmallRing::SetX(int x)
{
	m_ix = x;
	m_iCashX = m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx - m_pBitMapGold->GetSize().cx * 0.5f;
}

void SmallRing::UpdateRing(float deltaTime)
{
	m_ix -= (FIRE_SMALL_RING_SPEED * deltaTime);
	m_iCashX -= (FIRE_SMALL_RING_SPEED * deltaTime);
}
void SmallRing::ObstacleDraw(HDC hdc)
{
	if (m_bAnim)
	{
		m_pBitMap[FIRE_RING_2]->DrawTransSmall(hdc, m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx, m_iy);
	}
	else
	{
		m_pBitMap[FIRE_RING_4]->DrawTransSmall(hdc, m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx, m_iy);
	}
	if (m_ScoreCheck)
		m_pBitMapGold->DrawTrans(hdc, m_iCashX, m_iCashY);
	RectUpdate();


}

void SmallRing::RectUpdate()
{
	m_BitMapRect.left = m_ix + RING_WIDTH;
	m_BitMapRect.right = (m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx * 2) - RING_WIDTH;

	m_BitMapCashRect.left = m_iCashX;
	m_BitMapCashRect.right = m_iCashX + m_pBitMapGold->GetSize().cx;
}

void SmallRing::UpdateObstacle(int x, float deltaTime)
{
	m_ix -= x;
	m_iCashX -= x;
	Update();
	AnimationSwitch(deltaTime);
}


void SmallRing::Update()
{
	if (m_ix <= OBSTACLE_END_X) // ��ֹ� ��ġ �缳��
	{
		m_ix = OBSTACLE_START_X;
		m_iCashX = m_ix + m_pBitMap[FIRE_RING_1]->GetSize().cx - m_pBitMapGold->GetSize().cx * 0.5f;
		m_ScoreCheck = true;
	}

	RectUpdate();
}


void SmallRing::ObstacleFrontDraw(HDC hdc)
{
	if (m_bAnim)
	{
		m_pBitMap[FIRE_RING_1]->DrawTransSmall(hdc, m_ix, m_iy);
	}
	else
	{
		m_pBitMap[FIRE_RING_3]->DrawTransSmall(hdc, m_ix, m_iy);
	}
	RectUpdate();
}


void SmallRing::ColliderCheck_Score(Character* Player)
{
	if (m_ScoreCheck)
	{
		RECT player = Player->GetRect();
		RECT tmp;
		if (IntersectRect(&tmp, &m_BitMapCashRect, &player))
		{
			Player->PlusScore(OBSTACLE_SCORE);
			m_ScoreCheck = false;
		}
	}
}