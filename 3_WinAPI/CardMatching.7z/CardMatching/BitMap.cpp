#include "BitMap.h"

BitMap::BitMap()
{
}

void BitMap::Init(HDC hdc,char* FileName)
{
	MemDC = CreateCompatibleDC(hdc);
	m_BitMap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
	SelectObject(MemDC, m_BitMap);
	BITMAP BitMap_Info;
	GetObject(m_BitMap, sizeof(BitMap_Info), &BitMap_Info);
	m_Size.cx = BitMap_Info.bmWidth;
	m_Size.cy = BitMap_Info.bmHeight;
}
void BitMap::Draw(HDC hdc, int x, int y, int Size_x, int Size_y)
{
	StretchBlt(hdc, x, y, Size_x, Size_y, MemDC, 0, 0, m_Size.cx, m_Size.cy, SRCCOPY);
}

void BitMap::Draw(HDC hdc, int x, int y)
{								//���� ������ ���
	StretchBlt(hdc, x, y, m_Size.cx * REDUCE, m_Size.cy * REDUCE, MemDC, 0, 0, m_Size.cx, m_Size.cy, SRCCOPY);
}

BitMap::~BitMap()
{
	DeleteObject(m_BitMap);
	DeleteDC(MemDC);
}
