#include "WinApiEngine.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

namespace ENGINE
{
	WinApiEngine::
}