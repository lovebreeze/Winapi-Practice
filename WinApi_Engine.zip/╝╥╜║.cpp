#include "EngineMecro.h"

int APIENTRY wWinMain(_In_ HINSTANCE, _In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
	return 0;
}